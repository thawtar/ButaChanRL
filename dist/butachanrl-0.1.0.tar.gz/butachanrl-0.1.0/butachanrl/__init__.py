"""
ButaChanRL

A minimalist reinforcement learning library based on PyTorch.
"""

__version__ = "0.1.0"
__author__ = 'Thaw Tar'
__credits__ = 'Reinforcement Learning course by University of Alberta'