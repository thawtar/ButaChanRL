"""
ButaChanRL

A minimalist reinforcement learning library based on PyTorch.
"""

__version__ = "0.1.3"
__author__ = 'Thaw Tar'
__credits__ = 'Reinforcement Learning course by University of Alberta'

#from butachanrl.ExperienceReplay import ExperienceReplay
#from butachanrl.DQNAgent import DQNAgent
#from butachanrl.Network import DQN, DuelinDQN, ActorCritic
#from butachanrl.RL import RL